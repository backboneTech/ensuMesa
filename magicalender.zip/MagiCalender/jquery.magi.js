var d = new Date();
var month = d.getMonth();
var year = d.getFullYear();
var date = d.getDate();
var day = d.getDay();
var monthsArray = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
var monthsShorthand = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
var daysArray = new Array("Mon", "Tue", "Wed", "Thur", "Fri", "Sat", "Sun");
var eventsArray = new Array();
var dmPriority = "m";

;(function($){
	$.score = function(base, abbreviation, offset){
		offset = offset || 0;
		
		if(abbreviation.length == 0) return 0.9;
		if(abbreviation.length > base.length) return 0.0;
		
		for(var i = abbreviation.length; i > 0; i--){
			var sub_abbreviation = abbreviation.substring(0,i);
			var index = base.indexOf(sub_abbreviation);
			
			if(index < 0) continue;
			if(index + abbreviation.length > base.length + offset) continue;
			
			var next_string = base.substring(index+sub_abbreviation.length);
			var next_abbreviation = null;
			
			if(i >= abbreviation.length) next_abbreviation = '';
			else next_abbreviation = abbreviation.substring(i);
			
			var remaining_score = $.score(next_string, next_abbreviation,offset+index);
			
			if(remaining_score > 0){
				var score = base.length-next_string.length;
				
				if(index != 0){
					var j = 0;
					var c = base.charCodeAt(index-1);
					if(c==32 || c == 9){
						for(var j=(index-2); j >= 0; j--) {
							c = base.charCodeAt(j);
							score -= ((c == 32 || c == 9) ? 1 : 0.15);
						}
					}
					else{
						score -= index;
					}
				}
				score += remaining_score * next_string.length;
				score /= base.length;;
				return score;
			}
		}
		return 0.0;
	}
})(jQuery);

function pad(n, l){
	n = n+"";
	while(n.length < l){
		n = "0"+n;
	}
	return n;
}
function changeTime(obj){
	var clockD = new Date();
	var h = clockD.getHours();
	var m = clockD.getMinutes();
	var ap = "AM";
	if(h >= 12){
		ap = "PM";
		if(h != 12){
			h -= 12;
		}
	}
	if(h == 0){
		h = 12;
	}

	obj.innerHTML = pad(h, 2)+" : "+pad(m, 2)+"<span>"+ap+"</span>";
	
	setTimeout(function(){
		changeTime(obj);
	}, 5000);
}
function getDays(m, y){
	var monthLengthArray = new Array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
	y += Math.floor(m / 12);
	m = m % 12;
	if(m < 0){
		m += 12;
	}
	
	var dayNumber = monthLengthArray[m];
	if(m == 1 && (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0)){
		dayNumber++;
	}
	
	return dayNumber;
}
function getDateDays(tMonth, month, year, date){
	var dayNumber = date;
	
	while(tMonth != month){
		if(tMonth > month){
			tMonth--;
		}
		dayNumber -= getDays(tMonth, year);
		if(tMonth < month){
			tMonth++;
		}
	}
	
	return dayNumber;
}

function createCalender(obj){
	var iHTML = '';
	iHTML += '<div class="in">';
		iHTML += '<div class="header">';
			iHTML += '<div class="searchHolder">';
				iHTML += '<input type="button" class="search" value="" />';
				iHTML += '<input type="button" class="home" value="" />';
			iHTML += '</div>';
			iHTML += '<div class="clock"><span></span></div>';
			iHTML += '<div class="arrowHolder">';
				iHTML += '<input type="button" class="arrow left" value="" />';
				iHTML += '<input type="button" class="arrow right" value="" />';
			iHTML += '</div>';
			iHTML += '<h1 class="monthYear"></h1>';
		iHTML += '</div>';
		iHTML += '<div class="days">';
		for(var i = 0; i < 7; i++){
			iHTML += '<div>'+daysArray[i]+'</div>';
		}
		iHTML += '</div>';
		iHTML += '<div class="dates"></div>';
	iHTML += '</div>';
	
	var calenderBigBG = new Image();
	var modalBG = new Image();
	var searchSubmit = new Image();
	var searchText = new Image();
	calenderBigBG.src = "MagiCalender/calenderBigBG.png";
	modalBG.src = "MagiCalender/modalBG.png";
	searchSubmit.src = "MagiCalender/searchSubmit.png";
	searchText.src = "MagiCalender/searchText.png";
	
	obj.innerHTML = iHTML;
}

function fillCalender(obj, tMonth, tYear, highlight){
	var calenderObj = obj.parentNode.parentNode;
	var mod = ((day - getDateDays(tMonth, month, year, date)) % 7);
	if(mod < 0){
		mod += 7;
	}
	if(tMonth < month){
		mod = 6 - mod;
	}
	var targetYear = Math.floor(tMonth / 12) + tYear;
	var targetMonth = tMonth % 12;
	if(targetMonth < 0){
		targetMonth += 12;
	}
	
	var iHTML = "";
	var c = 0;
	for(var i = 0; i < mod; i++){
		iHTML += '<div class="out">'+(getDays(tMonth-1, tYear)-mod+i+1)+'</div>';
		c++;
	}
	for(var i = 1; i <= getDays(tMonth, tYear); i++){
		var classVal = "date";
		if(highlight == i){
			classVal += " searched";
		}
		if(date == i && month == tMonth && year == tYear){
			classVal += " today";
		}
		
		var span = 0;
		var importantJ;
		for(var j = 0; j < eventsArray.length; j++){
			if(eventsArray[j][0] == calenderObj){
				importantJ = j;
				for(var k = 0; k < eventsArray[j][1].length; k++){
					if(i == eventsArray[j][1][k][1] && targetMonth+1 == eventsArray[j][1][k][0] && targetYear == eventsArray[j][1][k][2]){
						span++;
					}
				}
			}
		}
		var onClickVal = "";
		if(span == 0){
			span = "";
		}
		else{
			span = "<span>"+span+" events</span>";
			classVal += " highlight";
			onClickVal = ' onclick="showDateDetails('+importantJ+', '+i+', '+targetMonth+', '+targetYear+')"';
		}
		iHTML += '<div class="'+classVal+'"'+onClickVal+'><p class="number">'+i+'</p>'+span+'</div>';
		c++;
	}
	mod = 8 - (c % 7);
	if((mod >= 0 && mod < 8) || c <= 28){
		for(var i = 1; i < mod; i++){
			iHTML += '<div class="out">'+i+'</div>';
			c++;
		}
	}
	obj.innerHTML = iHTML;
	
	
	var calenderObj = obj.parentNode.parentNode;
	if(c > 35){
		calenderObj.style.background = "url('MagiCalender/calenderBigBG.png')";
		calenderObj.style.height = "462px";
	}
	else{
		calenderObj.style.background = "url('MagiCalender/calenderBG.png')";
		calenderObj.style.height = "400px";
	}
	
	jQuery(".monthYear", obj.parentNode).each(function(){
		this.innerHTML = monthsArray[targetMonth]+" "+targetYear;
	});
}

function changeDate(arrowCounterP, obj, highlight){
	var Dir = "left";
	if(arrowCounterP < arrowCounter){
		Dir = "right";
	}
	jQuery(".dates", obj).fadeOut(200, function(){
		jQuery(".dates", obj).each(function(){
			fillCalender(this, month+arrowCounterP, year, highlight);
		});
		jQuery(".header", obj).effect("shake", {times: 1, distance: 10, direction: Dir}, 100);
		$(this).fadeIn(500);
	});
	
	return arrowCounterP;
}

var currentSearch;
function showSearchBox(obj){
	currentSearch = obj;
	$("#calenderModal:hidden").fadeIn(400, function(){
		$("#calenderSearchForm:hidden").fadeIn(200, function(){
			jQuery("input.text", this).each(function(){
				this.focus();
			});
		});
	});
	
	$("#calenderSearchForm").draggable({cancel: 'button', handle: 'h1'});
	
	$("#calenderSearchForm").each(function(){
		var offset = $(obj).offset();
		this.style.top = (offset.top + 100)+"px";
		this.style.left = "50%";
		jQuery("h1", this).each(function(){
			this.innerHTML = "Search a date or event.";
		});
		jQuery("input.text", this).each(function(){
			this.value = "";
		});
	});
}
function hideSearchBox(){
	$("#calenderSearchForm").fadeOut(200, function(){
		$("#calenderModal").fadeOut(400);
	});
}

function workOutSearch(search, obj){
	var searchValue, mode, result;
	if(searchValue = search.match(/\D+$/)){
		if(searchValue == search){
			mode = "s";
		}
		else{
			mode = "n";
		}
	}
	else{
		mode = "n";
	}
	if(mode == "n"){
		var splitSearch = search.split(" ");
		var c = 0;
		for(var i = 0; i < splitSearch.length; i++){
			if(splitSearch[i].length > 0){
				c++;
			}
		}
		mode = "string";
		if(c == 1){
			splitSearch = search.split(/[.\\/]/);
			c = 0;
			for(var i = 0; i < splitSearch.length; i++){
				if(splitSearch[i].match(/\d+$/)){
					if(splitSearch[i].length > 0){
						c++;
					}
				}
				else{
					i = splitSearch.length;
					c = 0;
				}
			}
			if(c == 2 || c == 3){
				mode = "number";
			}
			else{
				result = "toLookFor";
			}
		}
		if(c >= 2 && result != "toLookFor"){
			var searchDay = null;
			var searchMonth = null;
			var searchYear = null;
			
			var monthTaken, dayTaken;
			for(var i = 0; i < splitSearch.length; i++){
				if(splitSearch[i].length > 0){
					if(mode == "number"){
						if(searchMonth == null  && (dmPriority == "m" || searchDay != null)){
							searchMonth = parseInt(splitSearch[i])-1;
						}
						else if(searchDay == null  && (dmPriority == "d" || searchMonth != null)){
							searchDay = parseInt(splitSearch[i]);
						}
						else if(searchYear == null){
							if(splitSearch[i].length == 2){
								searchValue = parseInt(splitSearch[i]);
								if((year - (Math.floor(year / 100) * 100)) > searchValue){
									searchYear = parseInt((Math.floor(year / 100) * 100) + searchValue);
								}
								else{
									searchYear = parseInt(((Math.floor(year / 100) - 1) * 100) + searchValue);
								}
							}
							if(splitSearch[i].length == 4){
								searchYear = parseInt(splitSearch[i]);
							}
						}
					}
					else if(mode == "string"){
						if(searchMonth == null){
							for(var j = 0; j < monthsArray.length; j++){
								if(splitSearch[i].toLowerCase() == monthsArray[j].toLowerCase()){
									searchMonth = j;
									monthTaken = i;
								}
							}
							for(var j = 0; j < monthsShorthand.length; j++){
								if(splitSearch[i].toLowerCase() == monthsShorthand[j].toLowerCase()){
									searchMonth = j;
									monthTaken = i;
								}
							}
						}
						if(searchDay == null && monthTaken != i){
							if(searchValue = parseInt(splitSearch[i])){
								if((searchValue+"").length == 1 || (searchValue+"").length == 2){
									searchDay = parseInt(searchValue);
									dayTaken = i;
								}
							}
						}
						if(searchYear == null && monthTaken != i && dayTaken != i){
							if(searchValue = splitSearch[i].match(/\d+$/)){
								searchValue = searchValue[0];
								if(searchValue.length == 2){
									if((year - (Math.floor(year / 100) * 100)) > searchValue){
										searchValue = parseInt(searchValue);
										searchYear = parseInt((Math.floor(year / 100) * 100) + searchValue);
									}
									else{
										searchValue = parseInt(searchValue);
										searchYear = parseInt(((Math.floor(year / 100) - 1) * 100) + searchValue);
									}
								}
								if(searchValue.length == 4){
									searchYear = parseInt(searchValue);
								}
							}
						}
					}
				}
			}
			
			if(searchMonth != null && (searchYear != null || searchDay != null)){
				if(searchMonth < 0 || searchMonth > 11){
					searchMonth = null;
				}
				else if(searchDay < 0 || searchDay > getDays(searchMonth, searchYear)){
					searchDay = null;
				}
			}
			if(searchMonth != null && (searchYear != null || searchDay != null)){
				var highlight;
				if(searchDay != null){
					highlight = searchDay;
				}
				if(searchYear == null){
					searchYear = year;
				}
				var arrowCounterP = (searchMonth - month) + ((searchYear - year) * 12);
				arrowCounter = changeDate(arrowCounterP, obj, highlight);
				
				return true;
			}
			else{
				result = "toLookFor";
			}
		}
		else{
			result = "toLookFor";
		}
	}
	if(result == "toLookFor" || mode == "s"){
		var bestSoFar = 0;
		var bestDates = new Array();
		for(var j = 0; j < eventsArray.length; j++){
			if(eventsArray[j][0] == obj){
				for(var k = 0; k < eventsArray[j][1].length; k++){
					var current = eventsArray[j][1][k];
					var current3 = $.score(current[3].toLowerCase(), search.toLowerCase());
					var current4 = $.score(current[4].toLowerCase(), search.toLowerCase());
					if(current3 > bestSoFar){
						bestSoFar = current3;
						bestDates = new Array(current[0], current[1], current[2]);
					}
					if(current4 > bestSoFar){
						bestSoFar = current4;
						bestDates = new Array(current[0], current[1], current[2]);
					}
				}
			}
		}
		if(bestSoFar > 0.6){
			var arrowCounterP = (bestDates[0] - month - 1) + ((bestDates[2] - year) * 12);
			arrowCounter = changeDate(arrowCounterP, obj, bestDates[1]);
			
			return true;
		}
		else{
			result = "Failure";
		}
	}
	
	if(result == "Failure"){
		return false;
	}
}

function showDateDetails(j, targetDay, targetMonth, targetYear){
	var datesArray = eventsArray[j][1];
	var iHTML = "";
	for(var k = 0; k < datesArray.length; k++){
		if(targetDay == datesArray[k][1] && targetMonth+1 == datesArray[k][0] && targetYear == datesArray[k][2]){
			iHTML += "<h1>"+datesArray[k][3]+"</h1><p>"+datesArray[k][4]+"</p>";
		}
	}
	
	var box = jQuery(".date", eventsArray[j][0]).get(targetDay-1);
	$(box).effect("shake", {times: 2, distance: 5}, 100);
	
	$("#calenderModal:hidden").fadeIn(400, function(){
		$("#dateInfoBox:hidden").fadeIn(200);
	});
	
	$("#dateInfoBox").draggable({cancel: 'button', handle: 'h1:first'});
	
	$("#dateInfoBox").each(function(){
		var offset = $(eventsArray[j][0]).offset();
		this.style.top = (offset.top + 100)+"px";
		this.style.left = "50%";
		jQuery("#dateInfoScroller", this).each(function(){
			this.innerHTML = iHTML;
		});
	});
}
function hideInfoBox(){
	$("#dateInfoBox").fadeOut(200, function(){
		$("#calenderModal").fadeOut(400);
	});
}

var arrowCounter = 0;
jQuery.fn.magiCalender = function(priority, customDays, customMonths, customMonthsShort){
	if(customDays) daysArray = customDays;
	if(customMonths) monthsArray = customMonths;
	if(customMonthsShort) monthsShorthand = customMonthsShort;
	if(priority) dmPriority = priority;
	this.each(function(){
		this.style.overflow = "hidden";
		var allDates = new Array();
		jQuery(".event", this).each(function(){
			var dates = new Array();
			var date = jQuery("h2", this).get(0).innerHTML.split(/[.\\/]/);
			for(var i = 0; i < 3; i++){
				dates[i] = parseFloat(date[i]);
			}
			dates[3] = jQuery("h1", this).get(0).innerHTML;
			dates[4] = jQuery("p", this).get(0).innerHTML;
			allDates.push(dates);
		});
		eventsArray.push(new Array(this, allDates));
		
		createCalender(this);
		
		var calender = this;
		jQuery(".clock", this).each(function(){
			changeTime(this);
		});
		jQuery(".dates", this).each(function(){
			fillCalender(this, month, year);
		});
		jQuery(".arrow.left", this).click(function(){
			this.blur();
			arrowCounter = changeDate(arrowCounter-1, calender);
		});
		jQuery(".arrow.right", this).click(function(){
			this.blur();
			arrowCounter = changeDate(arrowCounter+1, calender);
		});
		jQuery(".search", this).click(function(){
			this.blur();
			showSearchBox(calender);
		});
		jQuery(".home", this).click(function(){
			this.blur();
			arrowCounter = changeDate(0, calender);
		});
	});
	
	$("body").each(function(){
		var modal = document.createElement("div");
		modal.id = "calenderModal";
		this.appendChild(modal);
		
		var BG = document.createElement("div");
		BG.id = "calenderModalBG";
		modal.appendChild(BG);
		
		var search = document.createElement("form");
		search.id = "calenderSearchForm";
		var iHTML = "";
		iHTML += '<h1>Search a date or event.</h1>';
		iHTML += '<div>';
			iHTML += '<input type="text" class="text" value="" />';
			iHTML += '<input type="submit" class="submit" value="" />';
		iHTML += '</div>';
		iHTML += '<a href="javascript: hideSearchBox();">Close</a>';
		search.innerHTML = iHTML;
		modal.appendChild(search);
		
		var dateInfo = document.createElement("div");
		dateInfo.id = "dateInfoBox";
		iHTML = "";
		iHTML += '<div id="dateInfoScroller">';
			iHTML += '<h1>Test text</h1>';
			iHTML += '<p>Test blah blah</p>';
		iHTML += '</div>';
		iHTML += '<a href="javascript: hideInfoBox();">Close</a>';
		dateInfo.innerHTML = iHTML;
		modal.appendChild(dateInfo);
		
		var prevSeconds = 0;
		$("#calenderSearchForm").submit(function(){
			var searchQuery;
			jQuery("input", this).each(function(){
				this.blur();
				if(this.type == "text"){
					searchQuery = this.value;
				}
			});
			var timeCheck = new Date();
			var seconds = timeCheck.getTime();
			if(searchQuery != "" && seconds > prevSeconds + 700){
				prevSeconds = seconds;
				if(workOutSearch(searchQuery, currentSearch) == true){
					hideSearchBox();
				}
				else{
					jQuery("h1", this).each(function(){
						this.innerHTML = "No results. Try again.";
					});
					$(this).effect("shake", {times: 2, distance: 10}, 60);
				}
			}
			
			return false;
		});
	});
};